<?php
/**
 * Description of ${name}
 *
 * @author ${user}
 */
class ${name} {
    //put your code here
}
